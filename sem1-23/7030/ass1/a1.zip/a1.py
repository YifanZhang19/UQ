""" A fancy tic-tac-toe game for CSSE1001/7030 A1. """
from constants import *

Board = list[list[str]]
Pieces = list[int]
Move = tuple[int, int, int]

# Write your functions here


def main() -> None:
    # Write your main code here
    pass


if __name__ == '__main__':
    main()
