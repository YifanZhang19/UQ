import tkinter as tk
from tkinter import filedialog # For masters task
from typing import Callable, Union, Optional
from a3_support import *
from model import *
from constants import *

# Implement your classes here

def play_game(root: tk.Tk, map_file: str) -> None:
    pass # Implement your play_game function here

def main() -> None:
    pass # Implement your main function here

if __name__ == '__main__':
    main()
